<?php

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require '../vendor/autoload.php';

    $nome_empresa            = "Portal One Informática";
    $emailContato            = "compras@portaloneinformatica.com.br";
    $smtp_contato            = "relay.mailbaby.net";
    $email_remetente         = "mb56872";
    $senha_remetente         = "qbwnDZcBm6fEJXxj64Wu";
    
    $assunto_padrao = "Contato via ".$nome_empresa;

    try {

        if(empty($nome_empresa)){
            throw new Exception("<h3>Ocorreu um Erro</h3><p><strong>\$nome_empresa</strong> não foi definido.</p>");
        }
        if(empty($smtp_contato)){
            throw new Exception("<h3>Ocorreu um Erro</h3><p><strong>\$smtp_contato</strong> não foi definido.</p>");
        }
        if(empty($email_remetente)){
            throw new Exception("<h3>Ocorreu um Erro</h3><p><strong>\$email_remetente</strong> não foi definido.</p>");
        }
        if(empty($senha_remetente)){
            throw new Exception("<h3>Ocorreu um Erro</h3><p><strong>\$senha_remetente</strong> não foi definido.</p>");
        }
        if(empty($emailContato)){
            throw new Exception("<h3>Ocorreu um Erro</h3><p><strong>\$emailContato</strong> não foi definido.</p>");
        }

        $dados = $_POST['data'];

        $nome          = $dados["Contato"]["nome"];
        $email         = $dados["Contato"]["email"];
        $telefone      = $dados["Contato"]["telefone"];
        $como_conheceu = $dados["Contato"]["como_conheceu"];
        $mensagem      = $dados["Contato"]["mensagem"];
        $emails_status = false;
        
        if(empty($nome)){
            throw new Exception("<h3>Ocorreu um Erro</h3><p><strong>Nome</strong> é um campo obrigatório.</p>");
        }
        if(empty($email)){
            throw new Exception("<h3>Ocorreu um Erro</h3><p><strong>Email</strong> é um campo obrigatório.</p>");
        }
        if(empty($telefone)){
            throw new Exception("<h3>Ocorreu um Erro</h3><p><strong>Telefone</strong> é um campo obrigatório.</p>");
        }
        if(empty($mensagem)){
            throw new Exception("<h3>Ocorreu um Erro</h3><p><strong>Mensagem</strong> é um campo obrigatório.</p>");
        }
        
        // Monta corpo da mensagem do email
        $conteudo  = "<h3>".$assunto_padrao."</h3>";
        $conteudo .= "<p><strong>Nome</strong>: " . $nome . "</p>";
        $conteudo .= "<p><strong>Email</strong>: " . $email . "</p>";
        $conteudo .= "<p><strong>Telefone</strong>: " . $telefone . "</p>";
        $conteudo .= "<p><strong>Como nos conheceu</strong>: " . $como_conheceu . "</p>";
        $conteudo .= "<p><strong>Mensagem</strong>: " . $mensagem . "</p>";

        // Disparo com autenticação
        $mail = new PHPMailer(true);
        $mail->IsSMTP();
        $mail->SMTPDebug = false;
        $mail->SMTPAuth  = true;
        $mail->Host      = $smtp_contato;
        $mail->Port      = 2525;
        $mail->Username  = $email_remetente;
        $mail->Password  = $senha_remetente;
        $mail->From      = 'contatos@portaloneinformatica.com';
        $mail->FromName  = 'ITM - Formulário de Contato';
        $mail->AddAddress($emailContato, $nome_empresa);
        $mail->AddReplyTo($email, $nome);

        // E-mails em cópia, adicionar uma nova linha para cada e-mail
        // $mail->addCC("email@qualitysmi.com.br");
        
        // E-mails em cópia oculta, adicionar uma nova linha para cada e-mail
        // $mail->addBCC("email@qualitysmi.com.br");
        
        $mail->isHTML(true);
        $mail->CharSet = "UTF-8";
        $mail->Subject  = $assunto_padrao;
        $mail->Body = $conteudo;

        if(!$mail->send()) {
            $emails_status = false;
        } else {
            $emails_status = true;
        }

        
        echo json_encode(array(
            "status" => true,
            "message" => $conteudo
        ));
    } catch (Exception $e) {
        echo json_encode(array(
            "status" => false,
            "message" => $e->getMessage()
        ));
    }
